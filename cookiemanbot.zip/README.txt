This Bot wat was made by cookieman6879 -- discord user: 8ti9

please report any bugs to 8ti9
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Common Errors:
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
not injecting: disable antivirus, check if swift key is active open SWIFT folder and open swift manually and do the key system
if still persists, dm me

no autoexec: go to SWIFT press AUTOEXEC and then create a text document and paste ur script into into

not joining roblox: ensure that an account is added to roblox account manager and that you selected the appropriate account number in the bot, the numbers are based on height, top being 1

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Honorable mention:

██╗  ██╗ ██████╗  ██████╗     ████████╗██╗   ██╗ █████╗ ██╗  ██╗
██║  ██║██╔═══██╗██╔════╝     ╚══██╔══╝██║   ██║██╔══██╗██║  ██║
███████║██║   ██║██║  ███╗       ██║   ██║   ██║███████║███████║
██╔══██║██║   ██║██║   ██║       ██║   ██║   ██║██╔══██║██╔══██║
██║  ██║╚██████╔╝╚██████╔╝       ██║   ╚██████╔╝██║  ██║██║  ██║
╚═╝  ╚═╝ ╚═════╝  ╚═════╝        ╚═╝    ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝
                                                                