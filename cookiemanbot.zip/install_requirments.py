import subprocess
import sys
import os
packages = [
    "pygetwindow",
    "pyautogui",
    "pywin32",  
    "psutil",
    "fade",
    "requests",
    "colorama"
]

def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

for package in packages:
    try:
        __import__(package)
        print(f"{package} is already installed.")
    except ImportError:
        print(f"{package} is not installed. Installing...")
        install(package)
        print(f"{package} has been installed successfully.")

os.system('cls')